-- MySQL dump 10.13  Distrib 5.7.40, for Linux (x86_64)
--
-- Host: localhost    Database: hire
-- ------------------------------------------------------
-- Server version	5.7.40-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `berkas`
--

DROP TABLE IF EXISTS `berkas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `berkas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_pengguna` int(11) DEFAULT NULL,
  `nama_berkas` varchar(100) DEFAULT NULL,
  `berkas` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_pengguna` (`id_pengguna`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `berkas`
--

LOCK TABLES `berkas` WRITE;
/*!40000 ALTER TABLE `berkas` DISABLE KEYS */;
INSERT INTO `berkas` VALUES (2,18,'1','65379057518330046-Fadilah Riczky- UA -MPPL.docx');
/*!40000 ALTER TABLE `berkas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_terkirim`
--

DROP TABLE IF EXISTS `email_terkirim`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `email_terkirim` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `subjek` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_terkirim`
--

LOCK TABLES `email_terkirim` WRITE;
/*!40000 ALTER TABLE `email_terkirim` DISABLE KEYS */;
INSERT INTO `email_terkirim` VALUES (3,'Fadilah Riczky','pelamar@gmail.com','Pendaftaran Berhasil'),(4,'Fadilah Riczky','pelamar@gmail.com','Pendaftaran Berhasil'),(5,'Fadilah Riczky','pelamar@gmail.com','Pendaftaran Belum Diterima !'),(6,'Fadilah Riczky','pelamar@gmail.com','Pendaftaran Berhasil'),(7,'Fadilah Riczky','pelamar@gmail.com','Pendaftaran Belum Diterima !');
/*!40000 ALTER TABLE `email_terkirim` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kategori_kerjaan`
--

DROP TABLE IF EXISTS `kategori_kerjaan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kategori_kerjaan` (
  `id_kategori` int(11) NOT NULL AUTO_INCREMENT,
  `kategori` varchar(100) NOT NULL,
  PRIMARY KEY (`id_kategori`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kategori_kerjaan`
--

LOCK TABLES `kategori_kerjaan` WRITE;
/*!40000 ALTER TABLE `kategori_kerjaan` DISABLE KEYS */;
INSERT INTO `kategori_kerjaan` VALUES (2,'Pertanian'),(5,'Kerja Santay'),(7,'Modal Good Looking');
/*!40000 ALTER TABLE `kategori_kerjaan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kerjaan`
--

DROP TABLE IF EXISTS `kerjaan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kerjaan` (
  `id_kerjaan` int(11) NOT NULL AUTO_INCREMENT,
  `id_kategori` int(11) DEFAULT NULL,
  `nama_kerjaan` varchar(200) DEFAULT NULL,
  `deskripsi` text,
  `foto` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id_kerjaan`) USING BTREE,
  KEY `id_kategori` (`id_kategori`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kerjaan`
--

LOCK TABLES `kerjaan` WRITE;
/*!40000 ALTER TABLE `kerjaan` DISABLE KEYS */;
INSERT INTO `kerjaan` VALUES (5,5,'Lowongan Kerja Jadi Maling','<p>Ini adalah lowongan kerja idaman untuk semua orang dimana kalian bisa jadi maling secara legal dilindungin negara.<br><br>syarat pendaftaran:</p><p>1. Melampirkan CV</p><p>2. Melampirkan Surat Lamaran Kerja</p><p>3. Minimal S1 Semua Jurusan</p><p>4. Lulusan S3 Di Utamakan</p>','32699141logo amikom.png'),(6,2,'Lowongan Kerja Jadi Tukang Cangkul','<p>Lowongan ini khusus bagi yang sudah expert dalam bidang mencangkul . Yang masih newbie minggir dulu !!</p><p>Syarat :&nbsp;</p><ul><li>Pendidikan : S1 Pertanian</li><li>Lampiran : CV dan Surat Lamaran Kerja</li><li>Diutamakan : S2 Manajemen Pertanian</li></ul>','1623362806e1.jpg'),(7,7,'Lowongan Kerja Mencari Cinta Sejati','<p>Ini adalah loker yang kalian tunggu-tunggu !!</p><p>Loker ini mencari orang terbaik yang masih blm memiliki pasangan hidup , dengan mendaftar disini kami akan mencarikan pasanganan hidup yang sesuai dengan apa yang kamu inginkan berdasarkan Portfolio kamu. Selain dicarikan pasangan kamu juga akan di berikan gaji dan tunjangan selama masih berpasangan dengan calon yang kami pilih.<br><br>Syarat&nbsp; :</p><ul><li>Lampiran : Portfolio dan Surat Lamaran Kerja</li><li>Pendidikan : Minimal S1 Semua Jurusan</li></ul><p>Tunjangan :</p><ul><li>Asuransi Kesehatan</li><li>BPJS</li><li>Tunjangan Transportasi</li><li>Paket Data</li><li>Laptop Spek Dewa</li></ul><p>Gaji :</p><ul><li>Bulan Pertama : 5 Juta</li><li>Bulan Selanjutnya : 5 Juta + 2 Juta Perbulan</li></ul>','1877533824e3.jpg');
/*!40000 ALTER TABLE `kerjaan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kontak`
--

DROP TABLE IF EXISTS `kontak`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kontak` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(200) DEFAULT NULL,
  `telpon` varchar(50) DEFAULT NULL,
  `alamat` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kontak`
--

LOCK TABLES `kontak` WRITE;
/*!40000 ALTER TABLE `kontak` DISABLE KEYS */;
INSERT INTO `kontak` VALUES (1,'email@email.com','089673881528','Jl. Damai Sejahtera, Komplek Perumahan Nusa Indah , Jetis , Jogja');
/*!40000 ALTER TABLE `kontak` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pengguna`
--

DROP TABLE IF EXISTS `pengguna`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pengguna` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_kerjaan` int(11) DEFAULT NULL,
  `nama` varchar(200) DEFAULT NULL,
  `password` varchar(200) DEFAULT NULL,
  `email` varchar(200) DEFAULT NULL,
  `telpon` varchar(50) DEFAULT NULL,
  `foto` varchar(200) DEFAULT NULL,
  `alamat` text,
  `role` int(10) DEFAULT NULL,
  `status_kerja` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pengguna`
--

LOCK TABLES `pengguna` WRITE;
/*!40000 ALTER TABLE `pengguna` DISABLE KEYS */;
INSERT INTO `pengguna` VALUES (1,NULL,'Fadilah Riczky','21232f297a57a5a743894a0e4a801fc3','admin@gmail.com',NULL,'189522226445.JANBADRA.png','',0,NULL),(18,5,'Fadilah Riczky','d106cd9e18dab5c9bce2b1b7c9a17d2b','pelamar@gmail.com','+6289673881528','768056353Gadjah_Mada_University_Logo.png','sasa',1,0),(19,NULL,'alfin','6ff92dee2a93081f0192781f156fa0e9','alfin@gmail.com',NULL,NULL,NULL,1,NULL),(24,NULL,'Fadilah Riczky','25d55ad283aa400af464c76d713c07ad','fadilahriczky07@gmail.com',NULL,NULL,NULL,1,NULL),(25,NULL,'Fadilah Riczky','25d55ad283aa400af464c76d713c07ad','fadilahriczky07@gmail.com',NULL,NULL,NULL,1,NULL),(26,NULL,'Fadilah Riczky','25d55ad283aa400af464c76d713c07ad','fadilahriczky07@gmail.com',NULL,NULL,NULL,1,NULL),(27,NULL,'Fadilah Riczky','25d55ad283aa400af464c76d713c07ad','fadilahriczky07@gmail.com',NULL,NULL,NULL,1,NULL),(28,NULL,'Fadilah Riczky','25d55ad283aa400af464c76d713c07ad','fadilahriczky07@gmail.com',NULL,NULL,NULL,1,NULL),(29,NULL,'Fadilah Riczky','25d55ad283aa400af464c76d713c07ad','fadilahriczky07@gmail.com',NULL,NULL,NULL,1,NULL),(30,NULL,'Fadilah Riczky','25d55ad283aa400af464c76d713c07ad','fadilahriczky07@gmail.com',NULL,NULL,NULL,1,NULL),(31,NULL,'Fadilah Riczky','25d55ad283aa400af464c76d713c07ad','fadilahriczky07@gmail.com',NULL,NULL,NULL,1,NULL),(32,NULL,'Fadilah Riczky','25d55ad283aa400af464c76d713c07ad','fadilahriczky07@gmail.com',NULL,NULL,NULL,1,NULL),(33,NULL,'Fadilah Riczky','25d55ad283aa400af464c76d713c07ad','fadilahriczky07@gmail.com',NULL,NULL,NULL,1,NULL),(34,NULL,'Fadilah Riczky','25d55ad283aa400af464c76d713c07ad','fadilahriczky07@gmail.com',NULL,NULL,NULL,1,NULL),(35,NULL,'Fadilah Riczky','25d55ad283aa400af464c76d713c07ad','fadilahriczky07@gmail.com',NULL,NULL,NULL,1,NULL),(36,NULL,'Fadilah Riczky','25d55ad283aa400af464c76d713c07ad','fadilahriczky07@gmail.com',NULL,NULL,NULL,1,NULL);
/*!40000 ALTER TABLE `pengguna` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `smtp_mail`
--

DROP TABLE IF EXISTS `smtp_mail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `smtp_mail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `host` varchar(123) NOT NULL,
  `email` varchar(111) NOT NULL,
  `password` varchar(111) NOT NULL,
  `port` varchar(111) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `smtp_mail`
--

LOCK TABLES `smtp_mail` WRITE;
/*!40000 ALTER TABLE `smtp_mail` DISABLE KEYS */;
INSERT INTO `smtp_mail` VALUES (1,'smtp.gmail.com','hirekaryawan@gmail.com','oosuwdtlqttelqhx\r\n','587');
/*!40000 ALTER TABLE `smtp_mail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tentang`
--

DROP TABLE IF EXISTS `tentang`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tentang` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama_web` varchar(250) DEFAULT NULL,
  `maps_url` text,
  `logo` text,
  `foto` text NOT NULL,
  `deskripsi` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tentang`
--

LOCK TABLES `tentang` WRITE;
/*!40000 ALTER TABLE `tentang` DISABLE KEYS */;
INSERT INTO `tentang` VALUES (1,'Hire Karyawan','<iframe src=\"https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d127669.05293968153!2d101.37113520024238!3d0.5137908161246251!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x31d5ab80690ee7b1%3A0x94dde92c3823dbe4!2sPekanbaru%2C%20Kota%20Pekanbaru%2C%20Riau!5e0!3m2!1sid!2sid!4v1658285170567!5m2!1sid!2sid\" width=\"800\" height=\"600\" style=\"border:0;\" allowfullscreen=\"\" loading=\"lazy\" referrerpolicy=\"no-referrer-when-downgrade\"></iframe>','674852765logo amikom.png','2058334161about-img.jpg','<p>Perusahaan kami termasuk dalam bidang penyaluran tenaga kerja bagi perusahaan atau lembaga lain yang membutuhkan , dengan adanya sistem seperti ini kami akan menyeleksi dengan tim professional agar dapat memberikan para pekerja yang terbaik sesuai kebutuhan perusahaan ataupun lembaga anda.</p>');
/*!40000 ALTER TABLE `tentang` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'hire'
--

--
-- Dumping routines for database 'hire'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-01-30 15:44:36
